#assignment: 06
#description: Working with Functions within Class
#changelog: (who,what,when)
#AKumar (2.23.23) created script
#Akumar (2.23.23) added data to script
#Akumar (2.23.23) completed script
#-------------------------------------#

#Defined Variables
strFile =  "PythonScripting.txt"
dicRow = {}
lstTable = []

class FileProcessor:

    def ReadDataToFile(strFile, lstTable):
        strFile = open("PythonScripting.txt", "r")
        for dicRow in lstTable:
            data = line.split(',')
            dicRow = {"Course": data[0].strip(), "Student":data[1].strip()}
            lstTable.append(dicRow)
        strFile.close()
        return lstTable

    def WriteListToFile(strFile, lstTable):
        strFile = open("PythonScripting.txt", 'w')
        for dicRow in lstTable:
            strFile.write(dicRow["Course"] + "," + dicRow["Student"] + "\n")
        strFile.close()

    def ShowMenuOptions(lstTable):
        strChoice = str(input("Chose Your Menu Option? [1 to 5] -")).strip()
        print()
        return strChoice

    def RemoveItemFromList(KeyToRemove,lstTable):
        item_removed = False
        intRowNumber = ["0"]
        while(intRowNumber < len(lstTable)):
            if(KeytoRemove == str(list(dict(lstTable[intRowNumber]).value())[0])):
                del lstTable[KeyToRemove]
                blnItemRemoved = True
            intRowNumber += 1
        return item_removed

    def AddRowToList(Course,Student, lstTable):
        dicRow = {"Course": Course, "Student": Student}
            lstTable.append(dicRow)


class IO:

    def OutputMenuItems():
        print("""
        Menu of Options
        1. Show Current Data
        2. Add new data
        3. Remove current data
        4. Save Data to File
        5. Reload Data to File
        6. Exit Data File
        """)
        print()

FileProcessor.ReadDataToFile("PythonScripting.txt", lstTable)
while(True):
    IO.OutputMenuItems()
    strChoice = IO.ShowMenuOption()

    if (objFile.strip() == '1'):
        IO.OutputMenuItems()

FileProcessor.WriteListToFile("PythonScripting.txt", lstTable)
def ShowListItemsFile():
    for dicRow in lstTable:
        while(True):

        IO.OutputMenuOptions()
        lstTable = IO.OutputMenuItems()
        IO.ShowCurrentMenuOptions(lstTable)
    continue

FileProcessor.AddRowToList(strCourse, strStudent, lstTable)
    elif(strChoice.strip() == "2"):
        strCourse = str(input("What is the Course? - ")).strip()
        strStudent = str(input("What is the Student Name?- ")).strip()
        strCourse, strStudent == IO.ShowCurrentMenuOptions()
        FileProcessor.AddRowToList(strCourse, strStudent, lstTable)

        Print(IO.ShowCurrentMenuOptions(lstTable))
        continue

    elif(strChoice == "3"):
        strKeyToRemove = input("Chose Your option to Remove? - ")
        blnItemRemoved = False
        blnItemRemoved = FileProcessor.RemoveItemsFromList(strKeyToRemove,lstTable)
        if(blnItemRemoved == True):
            print("The option was removed")
        else:
            print("The Option was not removed")
            IO.ShowCurrentMenuOptions(lstTable)
        print(IO.RemoveItemFromList(lstTable))

        continue

    elif(strChoice == "4"):
        IO.ShowCurrentMenuOptions(lstTable)
        if ("y" == str(input("Save the Data to the File [Y or N] - ")).strip().lower()):
            FileProcessor.WriteListToFile("PythonScripting.txt",lstTable)
            input("Data Saved to File, Press Enter to Return Menu Options.")
        else:
            input("File Data was not Saved, Press [Enter] to Return Menu Options.")
        print(IO.WriteListToFile(lstTable))
        continue

    elif (strChoice == ("5"):
        if (IO.InputSaveDataFile().lower() == 'y'):
            lstTable.clear()
            FileProcessor.ReadDataToFile("PythonScripting.txt", lstTable)
            IO.ShowCurrentMenuOptions(lstTable)
        else:
            input("File Data was not Reload, Press Enter to Return Menu Options.")
        print(IO.ShowCurrentMenuOptions(lstTable))
        continue






